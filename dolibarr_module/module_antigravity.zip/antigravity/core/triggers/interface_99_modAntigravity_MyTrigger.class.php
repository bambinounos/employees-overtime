<?php
require_once DOL_DOCUMENT_ROOT . '/core/triggers/nolanguages/interface_99_modAntigravity_MyTrigger.class.php';
require_once __DIR__ . '/../../lib/antigravity.lib.php';

class interface_99_modAntigravity_MyTrigger extends InterfaceTriggers
{
    public function __construct($db)
    {
        $this->db = $db;
        $this->name = preg_replace('/^interface_99_|_[^_]+$/i', '', get_class($this));
        $this->family = "antigravity";
        $this->description = "Triggers for Antigravity integration.";
        $this->version = '1.0';
        $this->picto = 'antigravity@antigravity';
    }

    public function run_trigger($action, $object, User $user, Translate $langs, Conf $conf)
    {
        global $db;

        // 1. BILL_VALIDATE (Invoice Validated)
        if ($action == 'BILL_VALIDATE') {
            $data = array(
                'trigger_code' => 'BILL_VALIDATE',
                'object' => array(
                    'id' => $object->id,
                    'ref' => $object->ref,
                    'total_ht' => $object->total_ht,
                    'fk_user_author' => $object->user_author_id, // Who created it
                    'fk_propal' => isset($object->fk_source_propal) ? $object->fk_source_propal : null, // Not standard in all versions, might need to query linked objects
                    // If simple linking isn't available, we might send what we have.
                    // Dolibarr links are complex (llx_element_element).
                    // For now, let's send what's on the object.
                )
            );
            $this->send($data);
        }

        // 2. PROPAL_VALIDATE (Proposal Validated)
        elseif ($action == 'PROPAL_VALIDATE') {
            $data = array(
                'trigger_code' => 'PROPAL_VALIDATE',
                'object' => array(
                    'id' => $object->id,
                    'ref' => $object->ref,
                    'total_ht' => $object->total_ht,
                    'fk_user_author' => $object->user_author_id
                )
            );
            $this->send($data);
        }

        // 3. PRODUCT_CREATE (New Product)
        elseif ($action == 'PRODUCT_CREATE') {
            $data = array(
                'trigger_code' => 'PRODUCT_CREATE',
                'object' => array(
                    'id' => $object->id,
                    'ref' => $object->ref,
                    'fk_user_author' => $user->id // Current user triggering action
                )
            );
            $this->send($data);
        }

        return 0; // Return 0 to allow other triggers to run
    }

    private function send($data)
    {
        global $conf;
        $webhook_url = $conf->global->ANTIGRAVITY_WEBHOOK_URL;
        $api_secret = $conf->global->ANTIGRAVITY_API_SECRET;

        AntigravityHelper::sendToDjango($webhook_url, $api_secret, $data);
    }
}
?>