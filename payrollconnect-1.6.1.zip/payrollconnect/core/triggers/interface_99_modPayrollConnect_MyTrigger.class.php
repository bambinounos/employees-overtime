<?php
/* Copyright (C) 2026 Bambinounos
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

require_once DOL_DOCUMENT_ROOT . '/core/triggers/dolibarrtriggers.class.php';
require_once __DIR__ . '/../../lib/payroll_connect.lib.php';

class InterfaceMyTrigger extends DolibarrTriggers
{
    public function __construct($db)
    {
        parent::__construct($db);
        $this->name = 'PayrollConnect';
        $this->family = "payroll_connect";
        $this->description = "Triggers for Payroll Connect integration: syncs invoices, proposals and product creations to Django payroll system.";
        $this->version = '1.6.1';
        $this->picto = 'fontawesome_chart-line_fas_#2c3e50';
    }

    /**
     * Function called when a Dolibarr business event occurs.
     *
     * @param string    $action     Event action code
     * @param Object    $object     Object concerned
     * @param User      $user       User performing the action
     * @param Translate $langs      Translation object
     * @param Conf      $conf       Configuration object
     * @return int                  0=OK, <0=KO
     */
    public function runTrigger($action, $object, User $user, Translate $langs, Conf $conf)
    {
        // 1. BILL_VALIDATE (Invoice or Credit Note validated)
        // Dolibarr: type=0 = Standard Invoice, type=2 = Credit Note
        // Per FEASIBILITY_REPORT sections 2.1 events 2 & 3
        if ($action == 'BILL_VALIDATE') {
            // Resolve the original proforma ID by traversing the document chain:
            // Invoice → Order → Proforma (via llx_element_element)
            $propal_id = null;
            $order_id = null;
            $object->fetchObjectLinked();

            // Direct link: Invoice → Proforma
            if (!empty($object->linkedObjectsIds['propal'])) {
                $propal_id = reset($object->linkedObjectsIds['propal']);
            }
            // Indirect: Invoice → Order → Proforma
            if (!empty($object->linkedObjectsIds['commande'])) {
                $order_id = reset($object->linkedObjectsIds['commande']);
                if (empty($propal_id)) {
                    require_once DOL_DOCUMENT_ROOT . '/commande/class/commande.class.php';
                    $order = new Commande($this->db);
                    if ($order->fetch($order_id) > 0) {
                        $order->fetchObjectLinked();
                        if (!empty($order->linkedObjectsIds['propal'])) {
                            $propal_id = reset($order->linkedObjectsIds['propal']);
                        }
                    }
                }
            }

            // For credit notes: fk_facture_source points to the original invoice
            $source_invoice_id = null;
            if ((int)$object->type == 2 && !empty($object->fk_facture_source)) {
                $source_invoice_id = $object->fk_facture_source;
            }

            $data = array(
                'trigger_code' => 'BILL_VALIDATE',
                'object' => array(
                    'id' => $object->id,
                    'ref' => $object->ref,
                    'type' => $object->type,
                    'total_ht' => $object->total_ht,
                    'fk_user_author' => $object->user_author_id,
                    'fk_propal' => $propal_id,
                    'fk_commande' => $order_id,
                    'fk_facture_source' => $source_invoice_id,
                    'date_validation' => dol_print_date($object->date_validation, 'dayrfc'),
                )
            );
            return $this->send($data);
        }

        // 2. PROPAL_VALIDATE (Proposal/Proforma validated)
        elseif ($action == 'PROPAL_VALIDATE') {
            $data = array(
                'trigger_code' => 'PROPAL_VALIDATE',
                'object' => array(
                    'id' => $object->id,
                    'ref' => $object->ref,
                    'total_ht' => $object->total_ht,
                    'fk_user_author' => $object->user_author_id,
                    'date_validation' => dol_print_date($object->date_validation, 'dayrfc'),
                )
            );
            return $this->send($data);
        }

        // 3. ORDER_VALIDATE (Order/Pedido validated)
        elseif ($action == 'ORDER_VALIDATE') {
            // Resolve linked proforma
            $propal_id = null;
            $object->fetchObjectLinked();
            if (!empty($object->linkedObjectsIds['propal'])) {
                $propal_id = reset($object->linkedObjectsIds['propal']);
            }

            $data = array(
                'trigger_code' => 'ORDER_VALIDATE',
                'object' => array(
                    'id' => $object->id,
                    'ref' => $object->ref,
                    'total_ht' => $object->total_ht,
                    'fk_user_author' => $object->user_author_id,
                    'fk_propal' => $propal_id,
                    'date_validation' => dol_print_date($object->date_validation, 'dayrfc'),
                )
            );
            return $this->send($data);
        }

        // 4. PAYMENT_CUSTOMER_CREATE (Customer payment received)
        // $object is Paiement, $object->amounts = array(invoice_id => amount_paid)
        elseif ($action == 'PAYMENT_CUSTOMER_CREATE') {
            $invoice_ids = array();
            if (!empty($object->amounts) && is_array($object->amounts)) {
                $invoice_ids = array_map('intval', array_keys($object->amounts));
            }

            $data = array(
                'trigger_code' => 'PAYMENT_CUSTOMER_CREATE',
                'object' => array(
                    'id' => $object->id,
                    'ref' => isset($object->ref) ? $object->ref : '',
                    'invoice_ids' => $invoice_ids,
                    'total_amount' => isset($object->amount) ? $object->amount : 0,
                    'date_payment' => dol_print_date(
                        isset($object->datepaye) ? $object->datepaye : dol_now(), 'dayrfc'
                    ),
                )
            );
            return $this->send($data);
        }

        // 4. PRODUCT_CREATE (New Product created)
        elseif ($action == 'PRODUCT_CREATE') {
            $data = array(
                'trigger_code' => 'PRODUCT_CREATE',
                'object' => array(
                    'id' => $object->id,
                    'ref' => $object->ref,
                    'fk_user_author' => $user->id,
                    'date_creation' => dol_print_date(dol_now(), 'dayrfc'),
                )
            );
            return $this->send($data);
        }

        return 0;
    }

    /**
     * Send data to Django via the helper, with retry queue on failure.
     *
     * @param array $data Payload to send
     * @return int 0=OK, -1=Error (queued for retry)
     */
    private function send($data)
    {
        global $conf;
        $webhook_url = getDolGlobalString('PAYROLL_CONNECT_WEBHOOK_URL');
        $api_secret = getDolGlobalString('PAYROLL_CONNECT_API_SECRET');

        if (empty($webhook_url) || empty($api_secret)) {
            dol_syslog("PayrollConnect: Module not configured (missing URL or Secret). Skipping.", LOG_WARNING);
            return 0;
        }

        $result = PayrollConnectHelper::sendToDjango($webhook_url, $api_secret, $data);

        if ($result === false) {
            // Queue for retry (per FEASIBILITY_REPORT section 2.1 "Cola de Reintentos")
            PayrollConnectHelper::queueForRetry($this->db, $data);
            return -1;
        }

        return 0;
    }
}
